# First Interaction


An action for filtering pull requests and issues from first-time contributors.
